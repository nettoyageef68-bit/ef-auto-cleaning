import { createFileRoute } from '@tanstack/react-router'
import {
  CalendarDays,
  Car,
  Check,
  Droplets,
  Gauge,
  Gift,
  Handshake,
  Lock,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
} from 'lucide-react'
import { useMemo, useState } from 'react'

export const Route = createFileRoute('/')({
  component: EFAutoCleaning,
})

type Lang = 'fr' | 'sq' | 'ar' | 'es' | 'de' | 'it'

const translations: Record<Lang, {
  nav: string[]; heroTitle: string; heroSub: string; bookBtn: string; aboBtn: string;
  contactTitle: string; servicesTitle: string; servicesSub: string; reserveBtn: string;
  whatsappLabel: string;
}> = {
  fr: {
    nav: ['Accueil','Galerie','Offres','Abonnement','Parrainage','Réserver','Admin'],
    heroTitle: 'Votre voiture comme neuve à domicile',
    heroSub: 'Nettoyage intérieur professionnel directement chez vous à Mulhouse et dans un rayon de 30 km.',
    bookBtn: 'Prendre RDV',
    aboBtn: 'Abonnement 29,99€',
    contactTitle: 'Contactez-nous directement',
    servicesTitle: 'Nos formules',
    servicesSub: 'Nettoyage intérieur à domicile - Mulhouse & environs',
    reserveBtn: 'Réserver',
    whatsappLabel: 'WhatsApp',
  },
  sq: {
    nav: ['Kreu','Galeria','Oferta','Abonim','Referim','Rezervo','Admin'],
    heroTitle: 'Makina juaj si e re, në shtëpinë tuaj',
    heroSub: 'Pastrim profesional i brendshëm direkt tek ju në Mulhouse dhe rreth 30 km.',
    bookBtn: 'Rezervo takim',
    aboBtn: 'Abonim 29,99€',
    contactTitle: 'Na kontaktoni drejtpërdrejt',
    servicesTitle: 'Pakot tona',
    servicesSub: 'Pastrim i brendshëm në shtëpi - Mulhouse & rrethinë',
    reserveBtn: 'Rezervo',
    whatsappLabel: 'WhatsApp',
  },
  ar: {
    nav: ['الرئيسية','المعرض','العروض','الاشتراك','الإحالة','احجز','الإدارة'],
    heroTitle: 'سيارتك كالجديدة في منزلك',
    heroSub: 'تنظيف داخلي احترافي مباشرة عندك في مولوز وفي نطاق 30 كم.',
    bookBtn: 'احجز موعداً',
    aboBtn: 'اشتراك 29,99€',
    contactTitle: 'اتصل بنا مباشرة',
    servicesTitle: 'باقاتنا',
    servicesSub: 'تنظيف داخلي في المنزل - مولوز والضواحي',
    reserveBtn: 'احجز',
    whatsappLabel: 'واتساب',
  },
  es: {
    nav: ['Inicio','Galería','Ofertas','Suscripción','Referidos','Reservar','Admin'],
    heroTitle: 'Tu coche como nuevo en casa',
    heroSub: 'Limpieza interior profesional directamente en tu domicilio en Mulhouse y en un radio de 30 km.',
    bookBtn: 'Reservar cita',
    aboBtn: 'Suscripción 29,99€',
    contactTitle: 'Contáctenos directamente',
    servicesTitle: 'Nuestros servicios',
    servicesSub: 'Limpieza interior a domicilio - Mulhouse y alrededores',
    reserveBtn: 'Reservar',
    whatsappLabel: 'WhatsApp',
  },
  de: {
    nav: ['Startseite','Galerie','Angebote','Abo','Empfehlung','Buchen','Admin'],
    heroTitle: 'Ihr Auto wie neu – bei Ihnen zu Hause',
    heroSub: 'Professionelle Innenreinigung direkt bei Ihnen in Mulhouse und im Umkreis von 30 km.',
    bookBtn: 'Termin buchen',
    aboBtn: 'Abo 29,99€',
    contactTitle: 'Kontaktieren Sie uns direkt',
    servicesTitle: 'Unsere Pakete',
    servicesSub: 'Innenreinigung vor Ort - Mulhouse & Umgebung',
    reserveBtn: 'Buchen',
    whatsappLabel: 'WhatsApp',
  },
  it: {
    nav: ['Home','Galleria','Offerte','Abbonamento','Referral','Prenota','Admin'],
    heroTitle: 'La tua auto come nuova a domicilio',
    heroSub: 'Pulizia interna professionale direttamente da te a Mulhouse e nel raggio di 30 km.',
    bookBtn: 'Prenota appuntamento',
    aboBtn: 'Abbonamento 29,99€',
    contactTitle: 'Contattaci direttamente',
    servicesTitle: 'I nostri pacchetti',
    servicesSub: 'Pulizia interna a domicilio - Mulhouse e dintorni',
    reserveBtn: 'Prenota',
    whatsappLabel: 'WhatsApp',
  },
}

type Section = 'home' | 'gallery' | 'services' | 'abonnement' | 'parrainage' | 'booking' | 'admin'
type Booking = {
  id: number
  name: string
  phone: string
  service: string
  date: string
  time: string
  car: string
  parrain: string
  status: 'new' | 'confirmed'
}
type Subscriber = { name: string; phone: string; car: string; depuis: string }
type Referral = { parrain: string; phone: string; filleul: string; filleulPhone: string; date: string }

const phone = '+33 6 05 59 63 81'
const phoneHref = 'tel:+33605596381'
const whatsappHref = 'https://wa.me/33605596381'
const navItems: Array<{ id: Section; label: string; featured?: boolean }> = [
  { id: 'home', label: 'Accueil' },
  { id: 'gallery', label: 'Galerie' },
  { id: 'services', label: 'Offres' },
  { id: 'abonnement', label: 'Abonnement', featured: true },
  { id: 'parrainage', label: 'Parrainage' },
  { id: 'booking', label: 'Réserver' },
  { id: 'admin', label: 'Admin' },
]

const services = [
  {
    icon: Sparkles,
    name: 'Pack Express',
    price: '50€',
    desc: "Nettoyage rapide et efficace pour remettre l'intérieur en état.",
    includes: ['Aspiration complète', 'Nettoyage tableau de bord', 'Vitres intérieures', 'Dépoussiérage rapide'],
  },
  {
    icon: ShieldCheck,
    name: 'Pack Confort',
    price: '80€',
    desc: 'Nettoyage complet en profondeur, sièges et moquettes inclus.',
    popular: true,
    includes: ['Aspiration complète', 'Tableau de bord + vitres', 'Dépoussiérage', 'Nettoyage des plastiques', 'Shampooing sièges ou moquettes'],
  },
  {
    icon: Car,
    name: 'Pack Premium',
    price: '150€',
    desc: "Le soin ultime, jusqu'aux contours de porte et moindres recoins.",
    includes: ['Tout du Pack Confort', 'Plastiques nettoyés à la brosse', 'Dans les moindres détails', 'Contours de porte nettoyés', 'Finitions soignées garanties'],
  },
]

const initialBookings: Booking[] = [
  { id: 1, name: 'Karim Bensalem', phone: '06 12 34 56 78', service: 'Pack Confort - 80€', date: '2026-05-07', time: '9h30', car: 'BMW Série 3', parrain: '', status: 'new' },
  { id: 2, name: 'Sophie Martin', phone: '07 89 01 23 45', service: 'Pack Premium - 150€', date: '2026-05-08', time: '14h30', car: 'Peugeot 5008', parrain: '', status: 'new' },
  { id: 3, name: 'Mehdi Larbi', phone: '06 55 44 33 22', service: 'Pack Express - 50€', date: '2026-05-09', time: '8h00', car: 'Renault Clio', parrain: '', status: 'new' },
]

function EFAutoCleaning() {
  const [section, setSection] = useState<Section>('home')
  const [lang, setLang] = useState<Lang>('fr')
  const t = translations[lang]
  const isRtl = lang === 'ar'

  const navItems: Array<{ id: Section; label: string; featured?: boolean }> = [
    { id: 'home', label: t.nav[0] },
    { id: 'gallery', label: t.nav[1] },
    { id: 'services', label: t.nav[2] },
    { id: 'abonnement', label: t.nav[3], featured: true },
    { id: 'parrainage', label: t.nav[4] },
    { id: 'booking', label: t.nav[5] },
    { id: 'admin', label: t.nav[6] },
  ]
  const [filter, setFilter] = useState('all')
  const [selectedSlot, setSelectedSlot] = useState('')
  const [simCount, setSimCount] = useState(1)
  const [bookings, setBookings] = useState<Booking[]>(initialBookings)
  const [subscribers, setSubscribers] = useState<Subscriber[]>([
    { name: 'Thomas Dupont', phone: '06 88 77 66 55', car: 'VW Golf', depuis: 'Mai 2026' },
    { name: 'Amira Benali', phone: '07 11 22 33 44', car: 'Renault Clio', depuis: 'Avril 2026' },
  ])
  const [referrals, setReferrals] = useState<Referral[]>([])
  const [adminOpen, setAdminOpen] = useState(false)
  const [adminTab, setAdminTab] = useState<'rdv' | 'abos' | 'parr' | 'stats' | 'settings'>('rdv')
  const [adminPassword, setAdminPassword] = useState('ef2024')
  const [emailjsConfig, setEmailjsConfig] = useState({ serviceId: '', templateId: '', publicKey: '' })
  const [reply, setReply] = useState<{ name: string; phone: string } | null>(null)
  const [message, setMessage] = useState('')
  const [bookingSuccess, setBookingSuccess] = useState(false)
  const [aboSuccess, setAboSuccess] = useState(false)
  const [refSuccess, setRefSuccess] = useState(false)
  const [bookingService, setBookingService] = useState('')

  const go = (id: Section) => {
    setSection(id)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const sim = useMemo(() => {
    const normal = simCount * 50
    const total = simCount === 1 ? 29.99 : 29.99 + (simCount - 1) * 40
    return { normal, total, saved: Math.round(normal - total) }
  }, [simCount])

  const submitBooking = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const first = String(form.get('fname') || '').trim()
    const phoneValue = String(form.get('phone') || '').trim()
    const service = String(form.get('service') || '').trim()
    if (!first || !phoneValue || !service) return
    setBookings((current) => [
      ...current,
      {
        id: current.length + 1,
        name: `${first} ${String(form.get('lname') || '').trim()}`.trim(),
        phone: phoneValue,
        service,
        date: String(form.get('date') || 'À confirmer'),
        time: selectedSlot || 'À définir',
        car: String(form.get('car') || 'Non précisé'),
        parrain: String(form.get('parrain') || ''),
        status: 'new',
      },
    ])
    setBookingSuccess(true)
    event.currentTarget.reset()
    setSelectedSlot('')
  }

  const submitAbo = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const name = String(form.get('abo_name') || '').trim()
    const phoneValue = String(form.get('abo_phone') || '').trim()
    if (!name || !phoneValue) return
    setSubscribers((current) => [...current, { name, phone: phoneValue, car: String(form.get('abo_car') || 'Non précisé'), depuis: '2026' }])
    setAboSuccess(true)
    event.currentTarget.reset()
  }

  const submitReferral = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const parrain = String(form.get('p_parrain') || '').trim()
    const filleul = String(form.get('p_filleul') || '').trim()
    if (!parrain || !filleul) return
    setReferrals((current) => [...current, { parrain, filleul, phone: String(form.get('p_phone') || ''), filleulPhone: String(form.get('p_filleul_phone') || ''), date: new Date().toLocaleDateString('fr-FR') }])
    setRefSuccess(true)
    event.currentTarget.reset()
  }

  const bookService = (serviceName: string) => {
    setBookingService(serviceName)
    go('booking')
  }

  return (
    <main className="site-shell" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="contact-bar"><Phone size={15} /> Appelez-nous : <a href={phoneHref}>{phone}</a><span>Mulhouse & environs - service à domicile</span></div>
      <nav className="top-nav">
        <button className="brand" onClick={() => go('home')} aria-label="Retour accueil"><span className="brand-mark">EF</span><span><strong>EF <em>AUTO</em> CLEANING</strong><small>Mulhouse & environs</small></span></button>
        <div className="nav-links">{navItems.map((item) => <button key={item.id} className={`${section === item.id ? 'active' : ''} ${item.featured ? 'featured' : ''}`} onClick={() => go(item.id)}>{item.featured && <Star size={13} />} {item.label}</button>)}</div>
        <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
          <div className="lang-switcher">
            {(['fr','sq','ar','es','de','it'] as Lang[]).map((l) => (
              <button key={l} onClick={() => setLang(l)} className={lang === l ? 'active' : ''} title={l === 'fr' ? 'Français' : l === 'sq' ? 'Shqip' : l === 'ar' ? 'العربية الجزائرية' : l === 'es' ? 'Español' : l === 'de' ? 'Deutsch' : 'Italiano'}>
                {l === 'fr' ? '🇫🇷' : l === 'sq' ? '🇦🇱' : l === 'ar' ? '🇩🇿' : l === 'es' ? '🇪🇸' : l === 'de' ? '🇩🇪' : '🇮🇹'}
              </button>
            ))}
          </div>
          <a className="nav-phone" href={phoneHref}><Phone size={16} /> {phone}</a>
        </div>
      </nav>

      {section === 'home' && <section className="page active home-page"><Hero go={go} t={t} /><ContactBlock t={t} /><HomeBanners go={go} /><Zones /><Inspection /><ServicePreview bookService={bookService} go={go} t={t} /><Testimonials /><Footer go={go} navItems={navItems} /></section>}
      {section === 'gallery' && <Gallery filter={filter} setFilter={setFilter} />}
      {section === 'services' && <Services bookService={bookService} t={t} />}
      {section === 'abonnement' && <Abonnement simCount={simCount} setSimCount={setSimCount} sim={sim} submitAbo={submitAbo} success={aboSuccess} />}
      {section === 'parrainage' && <Parrainage submitReferral={submitReferral} success={refSuccess} />}
      {section === 'booking' && <BookingForm submitBooking={submitBooking} selectedSlot={selectedSlot} setSelectedSlot={setSelectedSlot} bookingService={bookingService} success={bookingSuccess} />}
      {section === 'admin' && <Admin adminOpen={adminOpen} setAdminOpen={setAdminOpen} adminTab={adminTab} setAdminTab={setAdminTab} bookings={bookings} subscribers={subscribers} referrals={referrals} setBookings={setBookings} setReply={setReply} adminPassword={adminPassword} setAdminPassword={setAdminPassword} emailjsConfig={emailjsConfig} setEmailjsConfig={setEmailjsConfig} />}
      {reply && <ReplyModal reply={reply} message={message || `Bonjour ${reply.name.split(' ')[0]},\n\nVotre rendez-vous EF Auto Cleaning est confirmé.\nPour toute question : ${phone}\n\nCordialement,\nEF Auto Cleaning`} setMessage={setMessage} onClose={() => setReply(null)} />}

      {/* WhatsApp floating button */}
      <a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="whatsapp-fab" title={t.whatsappLabel}>
        <MessageCircle size={28} />
      </a>
    </main>
  )
}

function Hero({ go, t }: { go: (id: Section) => void; t: typeof translations['fr'] }) {
  return <div className="hero"><div className="hero-copy"><div className="eyebrow"><MapPin size={15} /> Service à domicile - Mulhouse & environs</div><h1>{t.heroTitle.includes('comme') ? <>Votre voiture <span>comme neuve</span> à domicile</> : t.heroTitle.includes('si e re') ? <>Makina juaj <span>si e re</span>, në shtëpinë tuaj</> : <>{t.heroTitle}</>}</h1><p>{t.heroSub}</p><div className="actions"><a className="btn gold" href={phoneHref}><Phone size={17} /> {phone}</a><button className="btn dark" onClick={() => go('booking')}><CalendarDays size={17} /> {t.bookBtn}</button><button className="btn green" onClick={() => go('abonnement')}><Star size={17} /> {t.aboBtn}</button></div><div className="stats"><span><strong>200+</strong> voitures traitées</span><span><strong>5★</strong> note moyenne</span><span><strong>3h</strong> durée moyenne</span></div></div><div className="hero-emblem"><span>EF</span><small>Auto Cleaning</small></div></div>
}

function SectionTitle({ title, accent, sub }: { title: string; accent: string; sub: string }) { return <header className="section-header"><h2>{title} <span>{accent}</span></h2><p>{sub}</p></header> }
function ContactBlock({ t }: { t: typeof translations['fr'] }) { return <div className="wide-card contact-block"><div><Phone size={34} /><span><strong>{t.contactTitle}</strong><small>Disponible 7j/7 - réponse rapide garantie</small></span></div><a href={phoneHref}>{phone}</a></div> }
function HomeBanners({ go }: { go: (id: Section) => void }) { return <><button className="wide-card abo-banner" onClick={() => go('abonnement')}><span><Star size={34} /><b>Abonnement mensuel</b><small>1 nettoyage inclus + -20% sur chaque passage supplémentaire + priorité réservation</small></span><strong>29,99€<small>/ mois</small></strong></button><div className="wide-card referral-banner"><span><Handshake size={32} /><b>Programme parrainage</b><small>Vous nous apportez un client : -10€ sur votre prochain nettoyage</small></span><strong>-10€</strong></div></> }
function Zones() { return <div className="wide-card zone-card"><MapPin size={30} /><div><h3>Zone d'intervention</h3><p>Déplacement à <b>Mulhouse</b> et dans un rayon de <b>30 km</b>.</p><div className="tags">{['Mulhouse','Illzach','Wittenheim','Kingersheim','Riedisheim','Brunstatt','Lutterbach','Pfastatt','Habsheim','Saint-Louis','Thann','et environs'].map((z) => <span key={z}>{z}</span>)}</div></div></div> }
function Inspection() { return <div className="wide-card inspection"><h3><Gift size={20} /> Inspection gratuite incluse</h3><p>Vérification gratuite des niveaux à chaque prestation.</p><div className="inspection-grid"><span><Gauge /> Liquide de refroidissement <b>GRATUIT</b></span><span><Droplets /> Liquide lave-glace <b>GRATUIT</b></span></div></div> }
function ServicePreview({ bookService, go, t }: { bookService: (s: string) => void; go: (id: Section) => void; t: typeof translations['fr'] }) { return <div className="preview"><h2>Nos <span>formules</span></h2><div className="mini-services">{services.map((s) => <article key={s.name}><s.icon /><h3>{s.name}</h3><strong>{s.price}</strong><small>+ inspection gratuite</small><button onClick={() => s.name === 'Pack Confort' ? bookService(`${s.name} - ${s.price}`) : go('services')}>{ t.reserveBtn}</button></article>)}</div></div> }
function Testimonials() { return <div className="testimonials"><h2>Ce qu'ils en <span>disent</span></h2>{['Résultat bluffant ! Mon intérieur est impeccable, comme neuf. Très professionnel.','Service top, très ponctuel. Le siège en cuir est parfaitement nettoyé.','L’abonnement mensuel est top : simple, régulier et avantageux.','Très bon travail, prestation complète. Rapport qualité/prix excellent.'].map((text, i) => <article key={text}><div>★★★★★</div><p>“{text}”</p><strong>{['Karim B.','Nathalie M.','Sofiane L.','Isabelle R.'][i]}</strong><small>{['BMW Série 3 - Mulhouse','Renault Kadjar - Illzach','Peugeot 308 - Wittenheim','Citroën C5 - Saint-Louis'][i]}</small></article>)}</div> }

function Gallery({ filter, setFilter }: { filter: string; setFilter: (f: string) => void }) { const items = [['siege','Sièges cuir'],['tapis','Tapis'],['tableau','Tableau de bord'],['vitres','Vitres'],['tapis','Sols complets'],['siege','Banquette'],['tableau','Commandes'],['vitres','Pare-brise']]; return <section className="page active"><SectionTitle title="Mes" accent="réalisations" sub="Avant / après - chaque voiture mérite le meilleur soin" /><div className="filters">{['all','siege','tapis','tableau','vitres'].map((f) => <button key={f} className={filter === f ? 'active' : ''} onClick={() => setFilter(f)}>{f === 'all' ? 'Tout voir' : f}</button>)}</div><div className="before-after"><article><b>Avant</b><Car size={56} /><p>Sièges tachés, poussière, tapis encrassés</p></article><article><b>Après</b><Sparkles size={56} /><p>Intérieur immaculé, odeur fraîche</p></article></div><div className="gallery-grid">{items.filter(([cat]) => filter === 'all' || filter === cat).map(([cat, label], i) => <article key={`${label}-${i}`} className={i % 4 === 0 ? 'tall' : ''}><div className={`gallery-visual ${cat}`}><Sparkles /></div><span>{label}</span></article>)}</div></section> }
function Services({ bookService, t }: { bookService: (s: string) => void; t: typeof translations['fr'] }) { return <section className="page active"><SectionTitle title="Nos" accent="formules" sub="Nettoyage intérieur à domicile - Mulhouse & environs" /><div className="services-grid">{services.map((s) => <article className={`service-card ${s.popular ? 'popular' : ''}`} key={s.name}>{s.popular && <span className="popular-badge">Populaire</span>}<s.icon size={36} /><h3>{s.name}</h3><p>{s.desc}</p><ul>{s.includes.map((item) => <li key={item}><Check size={15} /> {item}</li>)}<li className="gift"><Gift size={15} /> Inspection niveaux offerte</li></ul><strong>{s.price} <small>/ véhicule</small></strong><button onClick={() => bookService(`${s.name} - ${s.price}`)}>{ t.reserveBtn}</button></article>)}</div><div className="wide-card quote-card"><span><b>Besoin d'un devis ?</b><small>SUV, utilitaire, camping-car... adaptation à tous les véhicules.</small></span><a href={phoneHref}>{phone}</a></div></section> }
function Abonnement({ simCount, setSimCount, sim, submitAbo, success }: { simCount: number; setSimCount: (n: number) => void; sim: { normal: number; total: number; saved: number }; submitAbo: (e: React.FormEvent<HTMLFormElement>) => void; success: boolean }) { return <section className="page active"><SectionTitle title="Abonnement" accent="mensuel" sub="Le meilleur moyen de garder votre voiture toujours propre" /><div className="abo-page"><div className="abo-main"><div><span className="pill">Offre exclusive</span><h2>Pack abonnement mensuel</h2><p>1 nettoyage intérieur inclus chaque mois, priorité de réservation et -20% sur chaque passage supplémentaire.</p></div><strong>29,99€<small>par mois</small></strong></div><div className="features">{[['Nettoyage inclus','Pack Express inclus, valeur 50€'],['-20% supplémentaire','Réduction sur chaque passage en plus'],['Priorité réservation','Créneaux réservés avant les autres clients'],['Inspection offerte','Niveaux vérifiés gratuitement']].map(([a,b]) => <article key={a}><Star /><b>{a}</b><p>{b}</p></article>)}</div><div className="simulator"><h3>Simulez vos économies</h3><div className="sim-options">{[1,2,3].map((n) => <button className={simCount === n ? 'active' : ''} key={n} onClick={() => setSimCount(n)}>{n} fois</button>)}</div><div className="sim-result"><p>Sans abonnement : <b>{sim.normal}€</b></p><p>Avec abonnement : <b>{sim.total.toFixed(2).replace('.', ',')}€</b></p><strong>Économie : {sim.saved}€</strong></div></div><FormCard title="Je m'abonne" submit={submitAbo} button="S'abonner pour 29,99€/mois" success={success} green fields={[['abo_name','Prénom & Nom'],['abo_phone','Téléphone'],['abo_address','Adresse'],['abo_car','Votre véhicule']]} /></div></section> }
function Parrainage({ submitReferral, success }: { submitReferral: (e: React.FormEvent<HTMLFormElement>) => void; success: boolean }) { return <section className="page active"><SectionTitle title="Programme" accent="parrainage" sub="Partagez EF Auto Cleaning et économisez à chaque filleul" /><div className="parrainage-page"><div className="hero-card"><span>Offre exclusive</span><strong>-10€</strong><p>pour chaque client que vous nous apportez</p></div><div className="steps">{['Vous parlez de nous','Votre filleul réserve','Vous gagnez -10€'].map((s,i) => <article key={s}><b>0{i+1}</b><Handshake /><h3>{s}</h3></article>)}</div><FormCard title="Parrainer un proche" submit={submitReferral} button="Envoyer mon parrainage" success={success} fields={[['p_parrain','Votre prénom'],['p_phone','Votre téléphone'],['p_filleul','Prénom du filleul'],['p_filleul_phone','Téléphone du filleul']]} /></div></section> }
function FormCard({ title, fields, submit, button, success, green }: { title: string; fields: string[][]; submit: (e: React.FormEvent<HTMLFormElement>) => void; button: string; success: boolean; green?: boolean }) { return <form className="form-card" onSubmit={submit}><h3>{title}</h3><p>Ou appelez directement : <a href={phoneHref}>{phone}</a></p>{fields.map(([name,label]) => <label key={name}>{label}<input name={name} placeholder={label} /></label>)}<button className={green ? 'green-submit' : ''}>{button}</button>{success && <div className="success">Demande reçue. Contact rapide au {phone}.</div>}</form> }
function BookingForm({ submitBooking, selectedSlot, setSelectedSlot, bookingService, success }: { submitBooking: (e: React.FormEvent<HTMLFormElement>) => void; selectedSlot: string; setSelectedSlot: (s: string) => void; bookingService: string; success: boolean }) { return <section className="page active"><SectionTitle title="Prendre" accent="rendez-vous" sub="Formulaire ou appel direct" /><form className="booking-form" onSubmit={submitBooking}><h3>Votre réservation</h3><div className="form-row"><label>Prénom<input name="fname" required /></label><label>Nom<input name="lname" /></label></div><div className="form-row"><label>Téléphone<input name="phone" required /></label><label>Email<input name="email" type="email" /></label></div><label>Adresse d'intervention<input name="address" placeholder="Rue, code postal, ville" /></label><div className="form-row"><label>Formule souhaitée<select name="service" required defaultValue={bookingService} key={bookingService}><option value="">Choisir...</option><option>Pack Express - 50€</option><option>Pack Confort - 80€</option><option>Pack Premium - 150€</option><option>Abonné - 1 nettoyage inclus</option><option>Abonné - nettoyage supplémentaire (-20%)</option><option>Devis personnalisé</option></select></label><label>Type de véhicule<select name="vehicleType"><option>Citadine / Berline</option><option>SUV / Crossover</option><option>Monospace</option><option>Utilitaire</option></select></label></div><label>Marque & modèle<input name="car" /></label><label>Parrainé par<input name="parrain" /></label><label>Date souhaitée<input name="date" type="date" min={new Date().toISOString().split('T')[0]} /></label><div className="slots">{['8h00','9h30','11h00','13h00','14h30','16h00','17h30','19h00'].map((slot) => <button type="button" key={slot} disabled={['11h00','16h00'].includes(slot)} className={selectedSlot === slot ? 'selected' : ''} onClick={() => setSelectedSlot(slot)}>{slot}</button>)}</div><div className="free-note"><Gift size={16} /> Inspection gratuite incluse</div><label>Message<textarea name="message" /></label><button>Envoyer ma demande de RDV</button>{success && <div className="success">Demande envoyée. Rappel rapide prévu.</div>}</form></section> }
function Admin(props: { adminOpen: boolean; setAdminOpen: (v: boolean) => void; adminTab: 'rdv'|'abos'|'parr'|'stats'|'settings'; setAdminTab: (v: 'rdv'|'abos'|'parr'|'stats'|'settings') => void; bookings: Booking[]; subscribers: Subscriber[]; referrals: Referral[]; setBookings: React.Dispatch<React.SetStateAction<Booking[]>>; setReply: (r: {name:string; phone:string}) => void; adminPassword: string; setAdminPassword: (p: string) => void; emailjsConfig: {serviceId: string; templateId: string; publicKey: string}; setEmailjsConfig: (c: {serviceId: string; templateId: string; publicKey: string}) => void }) {
  const [pw, setPw] = useState('')
  const [loginError, setLoginError] = useState(false)
  const [changePwOpen, setChangePwOpen] = useState(false)
  const [oldPw, setOldPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [newPw2, setNewPw2] = useState('')
  const [pwMsg, setPwMsg] = useState('')
  const [emailNotif, setEmailNotif] = useState(true)
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [ejsService, setEjsService] = useState(props.emailjsConfig.serviceId)
  const [ejsTemplate, setEjsTemplate] = useState(props.emailjsConfig.templateId)
  const [ejsKey, setEjsKey] = useState(props.emailjsConfig.publicKey)
  const [ejsSaved, setEjsSaved] = useState(false)

  const login = (e: React.FormEvent) => {
    e.preventDefault()
    if (pw === props.adminPassword) { props.setAdminOpen(true); setLoginError(false) }
    else { setLoginError(true) }
  }

  const changePassword = (e: React.FormEvent) => {
    e.preventDefault()
    if (oldPw !== props.adminPassword) { setPwMsg('❌ Mot de passe actuel incorrect'); return }
    if (newPw.length < 4) { setPwMsg('❌ Minimum 4 caractères'); return }
    if (newPw !== newPw2) { setPwMsg('❌ Les mots de passe ne correspondent pas'); return }
    props.setAdminPassword(newPw)
    setPwMsg('✅ Mot de passe changé avec succès !')
    setOldPw(''); setNewPw(''); setNewPw2('')
    setTimeout(() => { setChangePwOpen(false); setPwMsg('') }, 2000)
  }

  const sendEmailNotification = async (booking: Booking) => {
    if (!emailNotif) return
    const { serviceId, templateId, publicKey } = props.emailjsConfig
    if (!serviceId || !templateId || !publicKey) return
    try {
      await fetch(`https://api.emailjs.com/api/v1.0/email/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          service_id: serviceId,
          template_id: templateId,
          user_id: publicKey,
          template_params: {
            to_email: 'nettoyageef68@gmail.com',
            client_name: booking.name,
            client_phone: booking.phone,
            service: booking.service,
            date: booking.date,
            time: booking.time,
            car: booking.car,
          }
        })
      })
    } catch {}
  }

  const makeCalendarLink = (b: Booking) => {
    const dateStr = b.date.replace(/-/g, '')
    const timeStr = b.time.replace('h','') + '00'
    const start = `${dateStr}T${timeStr.padStart(6,'0')}`
    const end = `${dateStr}T${(parseInt(timeStr.slice(0,2))+2).toString().padStart(2,'0')}${timeStr.slice(2)}`
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=EF+Auto+Cleaning+-+${encodeURIComponent(b.name)}&dates=${start}/${end}&details=${encodeURIComponent(`Client: ${b.name}\nTél: ${b.phone}\nVéhicule: ${b.car}\nService: ${b.service}`)}`
  }

  const newCount = props.bookings.filter(b => b.status === 'new').length

  return (
    <section className="page active admin-page">
      <div className="admin-head">
        <h2>Espace <span>admin</span></h2>
        {props.adminOpen && <div style={{display:'flex',gap:'8px'}}>
          <button className="btn-outline" onClick={() => setChangePwOpen(v => !v)}>🔑 Changer mot de passe</button>
          <button onClick={() => props.setAdminOpen(false)}>Déconnexion</button>
        </div>}
      </div>

      {!props.adminOpen ? (
        <form className="login-card" onSubmit={login}>
          <Lock />
          <h3>Connexion Admin</h3>
          <input type="password" value={pw} onChange={e => setPw(e.target.value)} placeholder="Mot de passe" autoFocus />
          <button>Se connecter</button>
          {loginError && <p style={{color:'#e74c3c',margin:'4px 0 0',fontSize:'14px'}}>❌ Mot de passe incorrect</p>}
          <small>Mot de passe par défaut : ef2024</small>
        </form>
      ) : (
        <>
          {changePwOpen && (
            <form className="pw-change-card" onSubmit={changePassword}>
              <h4>🔑 Changer le mot de passe</h4>
              <input type="password" value={oldPw} onChange={e => setOldPw(e.target.value)} placeholder="Mot de passe actuel" />
              <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} placeholder="Nouveau mot de passe" />
              <input type="password" value={newPw2} onChange={e => setNewPw2(e.target.value)} placeholder="Confirmer le nouveau" />
              <div style={{display:'flex',gap:'8px'}}>
                <button type="submit">Confirmer</button>
                <button type="button" onClick={() => { setChangePwOpen(false); setPwMsg('') }}>Annuler</button>
              </div>
              {pwMsg && <p style={{margin:'6px 0 0',fontSize:'14px'}}>{pwMsg}</p>}
            </form>
          )}

          <div className="tabs">
            {(['rdv','abos','parr','stats','settings'] as const).map(tab => (
              <button key={tab} className={props.adminTab === tab ? 'active' : ''} onClick={() => props.setAdminTab(tab)}>
                {tab === 'rdv' ? 'RDV' : tab === 'abos' ? 'Abos' : tab === 'parr' ? 'Parr.' : tab === 'stats' ? 'Stats' : '⚙️'}
                {tab === 'rdv' && newCount > 0 && <span>{newCount}</span>}
              </button>
            ))}
          </div>

          {props.adminTab === 'rdv' && (
            <div className="rdv-list">
              {props.bookings.length === 0 && <p className="empty">Aucun rendez-vous.</p>}
              {props.bookings.map(b => (
                <article key={b.id}>
                  <div>
                    <h3>{b.name} {b.status === 'new' && <span>Nouveau</span>}</h3>
                    <p>{b.phone} | {b.car}{b.parrain ? ` | Parrain: ${b.parrain}` : ''}</p>
                    <div style={{display:'flex',gap:'6px',flexWrap:'wrap',marginTop:'6px'}}>
                      <button onClick={() => props.setBookings(cur => cur.map(i => i.id === b.id ? {...i, status:'confirmed'} : i))}>✅ Confirmer</button>
                      <button onClick={() => props.setReply({name: b.name, phone: b.phone})}>💬 Répondre</button>
                      <a className="cal-btn" href={makeCalendarLink(b)} target="_blank" rel="noopener noreferrer">📅 Calendrier</a>
                      <button className="danger" onClick={() => props.setBookings(cur => cur.filter(i => i.id !== b.id))}>✕ Refuser</button>
                    </div>
                  </div>
                  <strong>{b.service}<small>{b.date} — {b.time}</small></strong>
                </article>
              ))}
            </div>
          )}

          {props.adminTab === 'abos' && <SimpleList items={props.subscribers.map(s => [`⭐ ${s.name}`, `${s.phone} | ${s.car}`, '29,99€/mois'])} />}
          {props.adminTab === 'parr' && (props.referrals.length ? <SimpleList items={props.referrals.map(r => [`${r.parrain} → ${r.filleul}`, `${r.phone} | ${r.filleulPhone}`, '-10€ à appliquer'])} /> : <p className="empty">Aucun parrainage enregistré.</p>)}
          {props.adminTab === 'stats' && (
            <div className="stat-grid">
              {[
                [String(props.bookings.length), 'RDV total'],
                [String(props.subscribers.length), 'Abonnés actifs'],
                [String(props.bookings.filter(b=>b.status==='confirmed').length), 'Confirmés'],
                ['4.9★', 'Note moyenne'],
              ].map(([a,b]) => <article key={b}><b>{a}</b><small>{b}</small></article>)}
            </div>
          )}

          {props.adminTab === 'settings' && (
            <div className="settings-panel">
              <h3>⚙️ Paramètres</h3>

              <div className="setting-block">
                <h4>📧 Notifications Email (EmailJS)</h4>
                <p>Recevez un email à <strong>nettoyageef68@gmail.com</strong> à chaque nouveau RDV.</p>
                <label className="toggle-row">
                  <span>Notifications activées</span>
                  <input type="checkbox" checked={emailNotif} onChange={e => setEmailNotif(e.target.checked)} />
                </label>
                <div className="emailjs-form">
                  <input value={ejsService} onChange={e => setEjsService(e.target.value)} placeholder="Service ID (ex: service_xxxxx)" />
                  <input value={ejsTemplate} onChange={e => setEjsTemplate(e.target.value)} placeholder="Template ID (ex: template_xxxxx)" />
                  <input value={ejsKey} onChange={e => setEjsKey(e.target.value)} placeholder="Public Key (ex: aBcDeFgHiJkLm)" />
                  <button onClick={() => { props.setEmailjsConfig({serviceId: ejsService, templateId: ejsTemplate, publicKey: ejsKey}); setEjsSaved(true); setTimeout(() => setEjsSaved(false), 2000) }}>
                    Enregistrer la configuration
                  </button>
                  {ejsSaved && <p style={{color:'#27ae60',margin:'6px 0 0'}}>✅ Configuration sauvegardée !</p>}
                </div>
                <details style={{marginTop:'12px'}}>
                  <summary style={{cursor:'pointer',color:'var(--gold)',fontWeight:600}}>📖 Comment configurer EmailJS ? (Guide)</summary>
                  <ol className="guide-steps">
                    <li>Allez sur <a href="https://www.emailjs.com" target="_blank" rel="noopener noreferrer">emailjs.com</a> → créez un compte gratuit</li>
                    <li>Ajoutez un service Gmail → connectez <strong>nettoyageef68@gmail.com</strong></li>
                    <li>Créez un template avec les variables : <code>{'{{client_name}}'}</code>, <code>{'{{client_phone}}'}</code>, <code>{'{{service}}'}</code>, <code>{'{{date}}'}</code>, <code>{'{{time}}'}</code>, <code>{'{{car}}'}</code></li>
                    <li>Copiez le <strong>Service ID</strong>, <strong>Template ID</strong> et <strong>Public Key</strong> ci-dessus</li>
                  </ol>
                </details>
              </div>

              <div className="setting-block">
                <h4>📅 Google Calendar</h4>
                <p>Pour chaque RDV, cliquez sur <strong>📅 Calendrier</strong> dans la liste des RDV — cela ouvre Google Calendar avec les détails du client pré-remplis.</p>
                <div className="cal-info">
                  <span>✅ Intégration active — bouton disponible sur chaque RDV</span>
                </div>
              </div>

              <div className="setting-block">
                <h4>🔑 Sécurité</h4>
                <button className="btn-outline" onClick={() => { setChangePwOpen(true); props.setAdminTab('rdv') }}>Changer le mot de passe Admin</button>
              </div>
            </div>
          )}
        </>
      )}
    </section>
  )
}
function SimpleList({ items }: { items: string[][] }) { return <div className="rdv-list">{items.map(([a,b,c]) => <article key={a}><div><h3>{a}</h3><p>{b}</p></div><strong>{c}</strong></article>)}</div> }
function ReplyModal({ reply, message, setMessage, onClose }: { reply: { name: string; phone: string }; message: string; setMessage: (v: string) => void; onClose: () => void }) { return <div className="modal"><form><h3>Répondre au client</h3><p>À : {reply.name} - {reply.phone}</p><textarea value={message} onChange={(e) => setMessage(e.target.value)} /><div><button type="button" onClick={onClose}>Annuler</button><button type="button" onClick={onClose}>Envoyer</button></div></form></div> }
function Footer({ go, navItems }: { go: (id: Section) => void; navItems: Array<{ id: Section; label: string; featured?: boolean }> }) { return <footer><div><h3>EF <span>Auto</span> Cleaning</h3><p>Nettoyage intérieur professionnel à domicile - Mulhouse et environs 30 km.</p></div><div><h4>Navigation</h4>{navItems.slice(1,6).map((n) => <button key={n.id} onClick={() => go(n.id)}>{n.label}</button>)}</div><div><h4>Contact</h4><a href={phoneHref}>{phone}</a><p>Mulhouse (68) & 30 km</p><p>Disponible 7j/7</p></div></footer> }
